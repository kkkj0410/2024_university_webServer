package kr.ac.kumoh.s20211171.w20211171controller

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class W20211171controllerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
