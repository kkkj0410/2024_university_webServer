package kr.ac.kumoh.s20211171.w20211171controller

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class W20211171controllerApplication

fun main(args: Array<String>) {
	runApplication<W20211171controllerApplication>(*args)
}
